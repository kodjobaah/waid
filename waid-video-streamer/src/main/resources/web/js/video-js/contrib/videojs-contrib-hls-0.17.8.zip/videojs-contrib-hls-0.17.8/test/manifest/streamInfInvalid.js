{
  "allowCache": true,
  "playlists": [
    {
      "attributes": {
        "PROGRAM-ID": 1
      },
      "uri": "media.m3u8"
    },
    {
      "uri": "media1.m3u8"
    }
  ],
  "discontinuityStarts": []
}