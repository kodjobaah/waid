{
  "allowCache": true,
  "mediaSequence": 0,
  "playlistType": "VOD",
  "segments": [
    {
      "byterange": {
        "length": 522828,
        "offset": 0
      },
      "duration": 10,
      "uri": "hls_450k_video.ts"
    }
  ],
  "targetDuration": 10,
  "endList": true,
  "discontinuitySequence": 0,
  "discontinuityStarts": []
}