{
  "allowCache": true,
  "mediaSequence": 0,
  "segments": [
    {
      "duration": 10,
      "uri": "/test/ts-files/zencoder/gogo/00001.ts"
    }
  ],
  "endList": true,
  "discontinuitySequence": 0,
  "discontinuityStarts": []
}