{
  "allowCache": true,
  "mediaSequence": 0,
  "targetDuration": 10,
  "segments": [
    {
      "uri": "001.ts"
    },
    {
      "uri": "002.ts",
      "duration": 9
    },
    {
      "uri": "003.ts",
      "duration": 7
    },
    {
      "uri": "004.ts",
      "duration": 10
    }
  ],
  "discontinuitySequence": 0,
  "discontinuityStarts": []
}